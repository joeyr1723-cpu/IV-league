export type EquityPoint = { date: string; equity: number }
export type ScoreInputs = {
  curve: EquityPoint[]
  riskFreeRateAnnual?: number
  avgLeverage?: number
  populationBenchmarks: {
    pctReturnMean: number; pctReturnStd: number;
    sharpeMean: number; sharpeStd: number;
    maxDDMean: number; maxDDStd: number;
    levMean: number; levStd: number;
  }
}

export function computeScore(i: ScoreInputs): number {
  const rfr = i.riskFreeRateAnnual ?? 0.02
  if (i.curve.length < 2) return 0
  const start = i.curve[0].equity
  const end = i.curve[i.curve.length - 1].equity
  const pctReturn = (end - start) / start
  const daily = i.curve.map((p, idx) => idx===0?0:(p.equity - i.curve[idx-1].equity)/i.curve[idx-1].equity).slice(1)
  const mean = daily.reduce((a,b)=>a+b,0)/daily.length
  const variance = daily.reduce((a,b)=>a+Math.pow(b-mean,2),0)/Math.max(1,daily.length-1)
  const stdev = Math.sqrt(variance)
  const sharpe = stdev===0?0:((mean - rfr/252)/stdev) * Math.sqrt(252)
  let peak = i.curve[0].equity, maxDD = 0
  for (const p of i.curve) { peak = Math.max(peak, p.equity); const dd = (peak - p.equity)/peak; maxDD = Math.max(maxDD, dd) }
  const lev = i.avgLeverage ?? 1
  const z = (x:number, m:number, s:number) => s>0? (x-m)/s : 0
  const pctReturnZ = z(pctReturn, i.populationBenchmarks.pctReturnMean, i.populationBenchmarks.pctReturnStd)
  const sharpeZ = z(sharpe, i.populationBenchmarks.sharpeMean, i.populationBenchmarks.sharpeStd)
  const maxDDZ = z(maxDD, i.populationBenchmarks.maxDDMean, i.populationBenchmarks.maxDDStd)
  const levZ = z(lev, i.populationBenchmarks.levMean, i.populationBenchmarks.levStd)
  const scoreRaw = 0.6*pctReturnZ + 0.25*sharpeZ - 0.1*maxDDZ - 0.05*levZ
  const score = Math.max(0, Math.min(100, 50 + 10*scoreRaw))
  return Math.round(score*10)/10
}
