export function Logo() {
  return (
    <div className="flex items-center gap-3 mb-6">
      <div className="w-12 h-12 rounded-full border border-gold-600 bg-ivy-800 grid place-items-center">
        <span className="text-gold-400 text-2xl font-semibold">IV</span>
      </div>
      <div>
        <h1 className="h1">IV League</h1>
        <p className="opacity-90 -mt-1">Compete by House. Win trophies. Master the markets.</p>
      </div>
    </div>
  )
}
