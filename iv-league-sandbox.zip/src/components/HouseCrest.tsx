export type House = 'DELTA'|'GAMMA'|'THETA'|'VEGA'|'RHO'

export function HouseCrest({ house }: { house: House }) {
  const map = {
    DELTA: { name: 'Delta', color: 'text-crimson', glyph: '∆' },
    GAMMA: { name: 'Gamma', color: 'text-royal', glyph: 'Γ' },
    THETA: { name: 'Theta', color: 'text-ivy-200', glyph: 'Θ' },
    VEGA:  { name: 'Vega', color: 'text-purple', glyph: 'ν' },
    RHO:   { name: 'Rho', color: 'text-gold-400', glyph: 'ρ' },
  } as const
  const h = map[house]
  return (
    <div className="flex items-center gap-3">
      <div className={`w-10 h-10 rounded-full border border-gold-500 grid place-items-center ${h.color} bg-ivy-800`}>
        <span className="text-xl">{h.glyph}</span>
      </div>
      <span className="uppercase tracking-widest">{h.name}</span>
    </div>
  )
}
