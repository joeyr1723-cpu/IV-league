import { HouseCrest, type House } from './HouseCrest'

type Row = { rank:number; name:string; house:House; score:number }

export function Leaderboard({ rows }: { rows: Row[] }) {
  return (
    <div className="card p-4">
      <h2 className="h1 mb-4">Leader Board</h2>
      <table className="w-full text-left">
        <thead className="text-gold-400">
          <tr>
            <th className="py-2">Rank</th>
            <th>Trader</th>
            <th>House</th>
            <th className="text-right">Score</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.rank} className="border-t border-ivy-700/60 hover:bg-ivy-800/60">
              <td className="py-2 w-16">{r.rank}</td>
              <td>{r.name}</td>
              <td className="py-2"><span className="opacity-80"><HouseCrest house={r.house} /></span></td>
              <td className="text-right font-semibold">{r.score.toFixed(1)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
