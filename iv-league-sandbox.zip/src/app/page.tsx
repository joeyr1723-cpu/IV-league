import { Leaderboard } from '@/components/Leaderboard'
import { Logo } from '@/components/Logo'

async function getRows() {
  // In CodeSandbox, fetch from local API route
  const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL ?? ''}/api/leaderboard`, { cache: 'no-store' })
  if (!res.ok) {
    // fallback if fetch fails in some environments
    return [
      { rank:1, name:'@volsmith', house:'VEGA', score:92.4 },
      { rank:2, name:'@delta_dan', house:'DELTA', score:88.7 },
      { rank:3, name:'@thetaqueen', house:'THETA', score:86.1 },
    ] as any
  }
  const data = await res.json()
  return data.rows
}

export default async function Home() {
  const rows = await getRows()
  return (
    <main>
      <Logo />
      <div className="grid md:grid-cols-2 gap-6">
        <section className="card p-4">
          <h3 className="h1 mb-2">Houses</h3>
          <ul className="space-y-1 opacity-90">
            <li>∆ <span className="font-semibold">Delta</span> — Conviction In Motion</li>
            <li>Γ <span className="font-semibold">Gamma</span> — Speed Favors The Prepared</li>
            <li>Θ <span className="font-semibold">Theta</span> — Time Is Our Edge</li>
            <li>ν <span className="font-semibold">Vega</span> — Order In Chaos</li>
            <li>ρ <span className="font-semibold">Rho</span> — Macro Moves Mountains</li>
          </ul>
        </section>
        <Leaderboard rows={rows} />
      </div>
      <p className="mt-6 text-sm opacity-70">Demo data only. Hook up brokers and real scoring next.</p>
    </main>
  )
}
