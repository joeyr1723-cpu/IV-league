import { NextResponse } from 'next/server'

export async function GET() {
  const rows = [
    { rank: 1, name: '@volsmith', house: 'VEGA', score: 92.4 },
    { rank: 2, name: '@delta_dan', house: 'DELTA', score: 88.7 },
    { rank: 3, name: '@thetaqueen', house: 'THETA', score: 86.1 },
    { rank: 4, name: '@gamma_joe', house: 'GAMMA', score: 81.9 },
    { rank: 5, name: '@rho_ranger', house: 'RHO', score: 79.5 },
  ]
  return NextResponse.json({ rows })
}
