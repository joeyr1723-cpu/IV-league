import type { Config } from 'tailwindcss'

export default <Config>{
  content: [
    "./src/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ivy: { 50:'#f3f6f3',100:'#e3ebe3',200:'#c1d3c2',300:'#97b398',400:'#69956a',500:'#3e7741',600:'#2f5c33',700:'#234528',800:'#18301b',900:'#0e1c10' },
        gold: { 400:'#d4af37',500:'#bfa12f',600:'#9f8727' },
        crimson: '#8C1D18',
        royal: '#27408B',
        purple: '#4B2E83'
      },
      fontFamily: { serif: ['EB Garamond', 'Georgia', 'serif'] }
    }
  },
  plugins: []
}
