# IV League (CodeSandbox-ready)

A minimal Next.js (App Router) project with an Ivy League theme, mock leaderboard, House crests, and a scoring util. **No database required**. Perfect for uploading directly to CodeSandbox.

## Run locally

```bash
npm install
npm run dev
```

## In CodeSandbox
1. Create a new **Next.js (TypeScript)** sandbox.
2. Upload this zip (drag & drop into the file explorer, or Import → Upload Zip).
3. Wait for dependencies to install, then click **Preview**.

## What’s inside
- Ivy color theme & typography (Tailwind)
- Home page with mock leaderboard
- House crests component
- API route `/api/leaderboard` (mock data)
- Scoring util (`src/lib/scoring.ts`) for future wiring

## Customize
- Edit `src/app/page.tsx` to change copy & layout.
- Update mock data in `src/app/api/leaderboard/route.ts`.
- Add your branding in `src/components/Logo.tsx`.
